#!/usr/bin/env perl
use strict;
$^W=1;

my $source = 'iif-logo-neu.eps';

my $out_color = 'ufcd-logo-iif-color';
my $out_gray = 'ufcd-logo-iif-gray';
my $out_black = 'ufcd-logo-iif-black';

my $prg_ps2pdf = 'ps2pdf';
my $prg_grep = 'grep';
my $prg_convert = 'convert';
my $prg_date = 'date';

chomp(my $date = `$prg_date +%Y-%m-%d`);

sub printall ($) {
    my $txt = shift;
    print CO $txt;
    print GR $txt;
    print BL $txt;
    1;
}

open(IN, '<', $source) or die "!!! Error: Cannot open `$source'!\n";
open(CO, '>', "$out_color.eps") or die "!!! Error: Cannot open `$out_color.eps'!\n";
open(GR, '>', "$out_gray.eps") or die "!!! Error: Cannot open `$out_gray.eps'!\n";
open(BL, '>', "$out_black.eps") or die "!!! Error: Cannot open `$out_black.eps'!\n";

printall <<"END_HEAD";
%!PS-Adobe-3.0 EPSF-3.0
END_HEAD

print CO "%%Title: ufcd-logo-iif-color ($date)\n";
print GR "%%Title: ufcd-logo-iif-gray ($date)\n";
print BL "%%Title: ufcd-logo-iif-black ($date)\n";
printall <<"END_HEAD";
%%BoundingBox: 0 0 204 204
%%HiResBoundingBox: 0 0 203.54 204
%%CropBox: 0 0 203.54 204
%%Pages: 1
%%CreationDate: 2002-12-02 11:46
%%DocumentData: Clean7Bit
%%LanguageLevel: 2
%%EndComments
%%Page: 1 1
save
9 dict begin
/c{curveto}bind def
/clp{clip newpath}bind def
/cp{closepath}bind def
/f{fill}bind def
/k{setcmykcolor}bind def
/l{lineto}bind def
/m{moveto}bind def
/op{setoverprint}bind def
END_HEAD

$/ = "\r";
while (<IN>) {
    last if /800 path_rez/;
}
my $patch = 0;
while (<IN>) {
    s/\s+$/\n/;
    last if /^grestore/;
    next if /^gsave/;
    next if /^\[1 0 0 1 0 0 \] concat$/;
    s/ mo$/ m/;
    s/ ln$/ l/;
    s/ cmyk$/ k/;
    s/ cv$/ c/;
    if (/167.691 203.672 166.492 203.993 165.324 203.993 c/) {
        $patch++;
        printall $_;
        printall <<'END_INS';
f
gsave
0 0 m
204 0 l
204 204 l
0 204 l
cp
65.8408 28.2925 m
38.7686 149.168 l
92.585 149.127 l
cp
eoclip
newpath
END_INS
        my $skip_line = <IN>;
        next;
    }
    if (/1 0.56 0 0 k/) {
        $patch++;
        print CO $_;
        print GR "0 0 0 .63 k\n";
        printall <<'END_INS';
f
grestore
END_INS
        while (<IN>) {
            if (/^f/) {
                $patch++;
                last;
            }
        }
        while (<IN>) {
            if (/^f/) {
                $patch++;
                last;
            }
        }
        next;
    }
    printall $_;
}
$patch == 4 or die "!!! Error: Parsing original EPS file!\n";

printall <<"END_TAIL";
end
restore
showpage
%%EOF
END_TAIL

close(IN);
close(CO);
close(GR);
close(BL);

foreach my $base (($out_color, $out_gray, $out_black)) {
    system("$prg_ps2pdf -dEPSCrop $base.eps $base.pdf");
    system("$prg_grep BoundingBox $base.eps>$base.bb");
    system("$prg_convert -transparent white $base.eps $base.png");
}

print "* Done.\n";

__END__
